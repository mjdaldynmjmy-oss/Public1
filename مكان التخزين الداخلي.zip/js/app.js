/* ==========================================
   AlMajami Store V6 Professional
   app.js
   الجزء الأول
========================================== */

loadDatabase();

// عناصر الصفحة
const storeName = document.getElementById("storeName");
const storeDescription = document.getElementById("storeDescription");
const logo = document.getElementById("logo");
const banner = document.getElementById("bannerImage");

const categoriesBox = document.getElementById("categories");

const allProducts = document.getElementById("allProducts");
const featuredProducts = document.getElementById("featuredProducts");
const newProducts = document.getElementById("newProducts");

const cartCount = document.getElementById("cartCount");

// تحميل إعدادات المتجر
function loadStore(){

    storeName.textContent =
    settings.storeName || "AlMajami Store";

    storeDescription.textContent =
    settings.description || "";

    logo.src =
    settings.logo || "images/logo.png";

    banner.src =
    settings.banner || "images/banner.jpg";

    document.documentElement.style.setProperty(
        "--primary",
        settings.theme.primary
    );

    document.documentElement.style.setProperty(
        "--secondary",
        settings.theme.secondary
    );

    document.documentElement.style.setProperty(
        "--background",
        settings.theme.background
    );

    document.documentElement.style.setProperty(
        "--text",
        settings.theme.text
    );

}
/* ==========================================
   الجزء الثاني
   إعدادات الصفحة
========================================== */

// روابط التواصل
function loadSocialLinks(){

    const facebook =
    document.getElementById("facebookLink");

    const instagram =
    document.getElementById("instagramLink");

    const telegram =
    document.getElementById("telegramLink");

    const youtube =
    document.getElementById("youtubeLink");

    const whatsapp =
    document.getElementById("whatsappButton");

    if(facebook)
        facebook.href =
        settings.social.facebook || "#";

    if(instagram)
        instagram.href =
        settings.social.instagram || "#";

    if(telegram)
        telegram.href =
        settings.social.telegram || "#";

    if(youtube)
        youtube.href =
        settings.social.youtube || "#";

    if(whatsapp){

        if(settings.social.whatsapp){

            whatsapp.href =
            settings.social.whatsapp;

            whatsapp.style.display="flex";

        }else{

            whatsapp.style.display="none";

        }

    }

}

// تحديث عداد السلة
function updateCartCounter(){

    const cart =
    JSON.parse(localStorage.getItem("cart")) || [];

    let total = 0;

    cart.forEach(item=>{

        total += Number(item.qty || 1);

    });

    if(cartCount){

        cartCount.textContent = total;

    }

}

// تشغيل الإعدادات
loadStore();

loadSocialLinks();

updateCartCounter();
/* ==========================================
   الجزء الثالث
   إنشاء وعرض المنتجات
========================================== */

// إنشاء بطاقة المنتج
function createProductCard(product){

    const isNew =
    product.newProduct
    ? `<span class="badge-new">جديد</span>`
    : "";

    const isFeatured =
    product.featured
    ? `<span class="badge-featured">⭐ مميز</span>`
    : "";

    const oldPrice =
    product.oldPrice > product.price
    ? `<del>${product.oldPrice} ${STORE.currency}</del>`
    : "";

    const stock =
    product.stock <= 0
    ? `<span style="color:red;font-weight:bold;">نفد المخزون</span>`
    : `<span style="color:green;font-weight:bold;">متوفر (${product.stock})</span>`;

    return `

<div class="product-card">

    ${isNew}

    ${isFeatured}

    <img src="${product.image}" alt="${product.name}">

    <div class="product-info">

        <h3 class="product-title">
            ${product.name}
        </h3>

        <p style="color:#666;">
            ${product.brand}
        </p>

        ${oldPrice}

        <p class="product-price">
            ${product.price} ${STORE.currency}
        </p>

        <p>
            ${stock}
        </p>

        <button
        class="buy-btn"
        onclick="openProduct(${product.id})">

        عرض المنتج

        </button>

    </div>

</div>

`;

}

// عرض المنتجات
function renderProducts(){

    allProducts.innerHTML = "";

    featuredProducts.innerHTML = "";

    newProducts.innerHTML = "";

    products.forEach(product=>{

        allProducts.innerHTML +=
        createProductCard(product);

        if(product.featured){

            featuredProducts.innerHTML +=
            createProductCard(product);

        }

        if(product.newProduct){

            newProducts.innerHTML +=
            createProductCard(product);

        }

    });

}
/* ==========================================
   الجزء الرابع
   التصنيفات والبحث
========================================== */

// عرض التصنيفات
function renderCategories(){

    categoriesBox.innerHTML = "";

    categories.forEach(category=>{

        const button =
        document.createElement("button");

        button.textContent = category;

        button.onclick = function(){

            filterProducts(category);

        };

        categoriesBox.appendChild(button);

    });

}

// فلترة المنتجات
function filterProducts(category){

    allProducts.innerHTML = "";

    let list = [...products];

    if(category !== "الكل"){

        list = list.filter(product=>

            product.category === category

        );

    }

    if(list.length === 0){

        allProducts.innerHTML = `
        <div class="empty-box">
            لا توجد منتجات في هذا التصنيف.
        </div>
        `;

        return;

    }

    list.forEach(product=>{

        allProducts.innerHTML +=
        createProductCard(product);

    });

}

// البحث
function searchProducts(){

    const keyword =
    document.getElementById("searchInput")
    .value
    .trim()
    .toLowerCase();

    allProducts.innerHTML = "";

    const result = products.filter(product=>

        product.name.toLowerCase().includes(keyword) ||

        product.brand.toLowerCase().includes(keyword) ||

        product.category.toLowerCase().includes(keyword)

    );

    if(result.length === 0){

        allProducts.innerHTML = `
        <div class="empty-box">
            لا توجد نتائج مطابقة.
        </div>
        `;

        return;

    }

    result.forEach(product=>{

        allProducts.innerHTML +=
        createProductCard(product);

    });

}

// زر البحث
document
.getElementById("searchBtn")
.addEventListener("click", searchProducts);

// البحث أثناء الكتابة
document
.getElementById("searchInput")
.addEventListener("keyup", searchProducts);

// تشغيل أولي
renderCategories();
renderProducts();
/* ==========================================
   الجزء الخامس
   واجهة المستخدم والتنقل
========================================== */

// فتح صفحة المنتج
function openProduct(id){

    localStorage.setItem("selectedProduct", id);

    window.location.href = "product.html";

}

// زر الرجوع للأعلى
const topButton =
document.getElementById("topButton");

if(topButton){

    window.addEventListener("scroll", function(){

        if(window.scrollY > 300){

            topButton.style.display = "flex";

        }else{

            topButton.style.display = "none";

        }

    });

    topButton.onclick = function(){

        window.scrollTo({

            top:0,

            behavior:"smooth"

        });

    };

}

// إخفاء شاشة التحميل
window.addEventListener("load", function(){

    const loader =
    document.getElementById("loader");

    if(loader){

        loader.style.opacity = "0";

        setTimeout(function(){

            loader.style.display = "none";

        },500);

    }

});
/* ==========================================
   الجزء السادس
   تحديث البيانات وتحسينات العرض
========================================== */

// تحديث الصفحة بالكامل
function refreshStore(){

    loadDatabase();

    loadStore();

    loadSocialLinks();

    updateCartCounter();

    renderCategories();

    renderProducts();

}

// في حال عدم وجود منتجات
function checkProducts(){

    if(products.length > 0) return;

    allProducts.innerHTML = `

<div class="empty-box">

<h2>📦 لا توجد منتجات حالياً</h2>

<p>

يمكنك إضافة المنتجات من لوحة الإدارة.

</p>

</div>

`;

    featuredProducts.innerHTML = "";

    newProducts.innerHTML = "";

}

// ترتيب المنتجات (المميزة ثم الجديدة)
function sortProducts(){

    products.sort((a,b)=>{

        if(a.featured !== b.featured){

            return b.featured - a.featured;

        }

        if(a.newProduct !== b.newProduct){

            return b.newProduct - a.newProduct;

        }

        return b.id - a.id;

    });

}

// تشغيل عند تحديث البيانات
sortProducts();

checkProducts();
/* ==========================================
   الجزء السابع
   تحسينات الأداء والتحديث
========================================== */

// تحديث عند الرجوع إلى الصفحة
window.addEventListener("pageshow", function(){

    refreshStore();

});

// تحديث عداد السلة عند تغييرها
window.addEventListener("storage", function(e){

    if(e.key === "cart"){

        updateCartCounter();

    }

});

// إعادة تحميل البيانات كل 30 ثانية
setInterval(function(){

    loadDatabase();

    updateCartCounter();

},30000);

// تحديث المنتجات عند استعادة التركيز
window.addEventListener("focus", function(){

    refreshStore();

});

// تحسين تحميل الصور
document.querySelectorAll("img").forEach(function(img){

    img.loading = "lazy";

    img.onerror = function(){

        this.src = "images/no-image.png";

    };

});
/* ==========================================
   الجزء الثامن
   التشغيل النهائي
========================================== */

// تشغيل التطبيق
function initializeApp(){

    // تحميل قاعدة البيانات
    loadDatabase();

    // ترتيب المنتجات
    sortProducts();

    // تحميل إعدادات المتجر
    loadStore();

    // روابط التواصل
    loadSocialLinks();

    // تحديث عداد السلة
    updateCartCounter();

    // عرض التصنيفات
    renderCategories();

    // عرض المنتجات
    renderProducts();

    // التحقق من وجود منتجات
    checkProducts();

}

// تشغيل بعد تحميل الصفحة
document.addEventListener("DOMContentLoaded", function(){

    initializeApp();

});

// حفظ آخر وقت تشغيل
localStorage.setItem(
    "lastOpen",
    new Date().toISOString()
);

// دالة لإعادة تحميل المتجر عند الحاجة
function reloadStore(){

    refreshStore();

}

// نهاية الملف
/* ==========================================
   الدخول السري للإدارة
========================================== */

let adminClicks = 0;

const logoImage = document.getElementById("logo");

if (logoImage) {

    logoImage.addEventListener("click", function () {

        adminClicks++;

        if (adminClicks >= 5) {

            adminClicks = 0;

            window.location.href = "login.html";

        }

        setTimeout(() => {

            adminClicks = 0;

        }, 3000);

    });

}