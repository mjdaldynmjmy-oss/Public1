/* ==========================================
   AlMajami Store V6 Professional
   database.js
   الجزء الأول
========================================== */

// قاعدة البيانات
let products = [];
let categories = [];
let settings = {};

// إنشاء قاعدة البيانات لأول مرة
function createDatabase() {

    products = [];

    categories = [
        "الكل",
        "هواتف",
        "إكسسوارات",
        "مودمات",
        "بطاريات"
    ];

    settings = {

        storeName: "AlMajami Store",

        description: "متجر متخصص في الهواتف والإلكترونيات",

        logo: "images/logo.png",

        banner: "images/banner.jpg",

        theme: {

            primary: "#0d6efd",

            secondary: "#198754",

            background: "#f5f7fb",

            text: "#222222"

        },

        social: {

            whatsapp: "",

            facebook: "",

            instagram: "",

            telegram: "",

            youtube: ""

        }

    };

}

/* ==========================================
   تحميل وحفظ قاعدة البيانات
========================================== */

function loadDatabase() {

    const savedProducts =
        localStorage.getItem("products");

    const savedCategories =
        localStorage.getItem("categories");

    const savedSettings =
        localStorage.getItem("settings");

    // إنشاء قاعدة البيانات لأول تشغيل فقط
    if (
        savedProducts === null &&
        savedCategories === null &&
        savedSettings === null
    ) {

        createDatabase();
        saveDatabase();
        return;

    }

    try {

        products = savedProducts
            ? JSON.parse(savedProducts)
            : [];

        categories = savedCategories
            ? JSON.parse(savedCategories)
            : ["الكل"];

        settings = savedSettings
            ? JSON.parse(savedSettings)
            : {};

    } catch (error) {

        console.error("Database Error:", error);

        createDatabase();
        saveDatabase();

    }

}
/* ==========================================
   الجزء الثاني
   حفظ البيانات والتحقق
========================================== */

// حفظ البيانات
function saveDatabase() {

    localStorage.setItem(
        "products",
        JSON.stringify(products)
    );

    localStorage.setItem(
        "categories",
        JSON.stringify(categories)
    );

    localStorage.setItem(
        "settings",
        JSON.stringify(settings)
    );

}

// التحقق من سلامة قاعدة البيانات
function validateDatabase() {

    if (!Array.isArray(products)) {

        products = [];

    }

    if (!Array.isArray(categories)) {

        categories = ["الكل"];

    }

    if (!categories.includes("الكل")) {

        categories.unshift("الكل");

    }

    if (!settings || typeof settings !== "object") {

        createDatabase();

    }

    settings.storeName ??= "AlMajami Store";
    settings.description ??= "";
    settings.logo ??= "images/logo.png";
    settings.banner ??= "images/banner.jpg";

    settings.theme ??= {};

    settings.theme.primary ??= "#0d6efd";
    settings.theme.secondary ??= "#198754";
    settings.theme.background ??= "#f5f7fb";
    settings.theme.text ??= "#222222";

    settings.social ??= {};

    settings.social.whatsapp ??= "";
    settings.social.facebook ??= "";
    settings.social.instagram ??= "";
    settings.social.telegram ??= "";
    settings.social.youtube ??= "";

    products.forEach(product => {

        product.id ??= Date.now() + Math.random();

        product.name ??= "";

        product.brand ??= "";

        product.category ??= "الكل";

        product.price ??= 0;

        product.oldPrice ??= 0;

        product.stock ??= 0;

        product.description ??= "";

        product.image ??= "images/no-image.png";

        product.featured ??= false;

        product.newProduct ??= false;

    });

}