/* ==========================================
   AlMajami Store V2
   orders.js
========================================== */

loadDatabase();

// تحميل الطلبات
let orders = JSON.parse(localStorage.getItem("orders")) || [];

const ordersList = document.getElementById("ordersList");

// عرض الطلبات
function renderOrders() {

    ordersList.innerHTML = "";

    if (orders.length === 0) {

        ordersList.innerHTML = `
        <div class="empty">
            لا توجد طلبات حتى الآن.
        </div>
        `;

        return;
    }

    orders.forEach((order, index) => {

        ordersList.innerHTML += `

        <div class="order-card">

            <h3>🧾 الطلب #${index + 1}</h3>

            <p><strong>الاسم:</strong> ${order.customerName}</p>

            <p><strong>الهاتف:</strong> ${order.customerPhone}</p>

            <p><strong>العنوان:</strong> ${order.customerAddress}</p>

            <p><strong>الإجمالي:</strong> ${order.total} ${STORE.currency}</p>

            <p><strong>التاريخ:</strong> ${order.date}</p>

            <button onclick="deleteOrder(${index})">
                🗑 حذف الطلب
            </button>

        </div>

        `;

    });

}

// حذف طلب
function deleteOrder(index){

    if(!confirm("هل تريد حذف هذا الطلب؟")) return;

    orders.splice(index,1);

    localStorage.setItem("orders", JSON.stringify(orders));

    renderOrders();

}

// تشغيل
renderOrders();