/* ==========================================
   AlMajami Store V3
   product.js
   الجزء الأول
========================================== */

loadDatabase();

// ==========================
// قراءة المنتج
// ==========================

const productId =
Number(localStorage.getItem("selectedProduct"));

const product =
products.find(item => item.id === productId);

// عناصر الصفحة
const productImage =
document.getElementById("productImage");

const productName =
document.getElementById("productName");

const productBrand =
document.getElementById("productBrand");

const productPrice =
document.getElementById("productPrice");

const productDescription =
document.getElementById("productDescription");

const stockStatus =
document.getElementById("stockStatus");

// إذا لم يوجد المنتج
if(!product){

    document.querySelector(".product-container").innerHTML = `

    <div style="
        text-align:center;
        padding:60px;
    ">

        <h2>المنتج غير موجود</h2>

        <br>

        <a href="index.html">
        العودة للرئيسية
        </a>

    </div>

    `;

    throw new Error("Product Not Found");

}

// تعبئة البيانات

productImage.src = product.image;

productName.textContent = product.name;

productBrand.textContent =
"الماركة : " + product.brand;

productPrice.textContent =
product.price + " " + STORE.currency;

productDescription.textContent =
product.description;

// حالة المخزون

if(product.stock <= 0){

    stockStatus.innerHTML =
    "<span style='color:red;font-weight:bold;'>🔴 نفد المخزون</span>";

}else if(product.stock <= 5){

    stockStatus.innerHTML =
    "<span style='color:#ff9800;font-weight:bold;'>🟡 كمية قليلة ("+product.stock+")</span>";

}else{

    stockStatus.innerHTML =
    "<span style='color:green;font-weight:bold;'>🟢 متوفر ("+product.stock+")</span>";

}
/* ==========================================
   AlMajami Store V3
   product.js
   الجزء الأول
========================================== */

loadDatabase();

// ==========================
// قراءة المنتج
// ==========================

const productId =
Number(localStorage.getItem("selectedProduct"));

const product =
products.find(item => item.id === productId);

// عناصر الصفحة
const productImage =
document.getElementById("productImage");

const productName =
document.getElementById("productName");

const productBrand =
document.getElementById("productBrand");

const productPrice =
document.getElementById("productPrice");

const productDescription =
document.getElementById("productDescription");

const stockStatus =
document.getElementById("stockStatus");

// إذا لم يوجد المنتج
if(!product){

    document.querySelector(".product-container").innerHTML = `

    <div style="
        text-align:center;
        padding:60px;
    ">

        <h2>المنتج غير موجود</h2>

        <br>

        <a href="index.html">
        العودة للرئيسية
        </a>

    </div>

    `;

    throw new Error("Product Not Found");

}

// تعبئة البيانات

productImage.src = product.image;

productName.textContent = product.name;

productBrand.textContent =
"الماركة : " + product.brand;

productPrice.textContent =
product.price + " " + STORE.currency;

productDescription.textContent =
product.description;

// حالة المخزون

if(product.stock <= 0){

    stockStatus.innerHTML =
    "<span style='color:red;font-weight:bold;'>🔴 نفد المخزون</span>";

}else if(product.stock <= 5){

    stockStatus.innerHTML =
    "<span style='color:#ff9800;font-weight:bold;'>🟡 كمية قليلة ("+product.stock+")</span>";

}else{

    stockStatus.innerHTML =
    "<span style='color:green;font-weight:bold;'>🟢 متوفر ("+product.stock+")</span>";

}
/* ==========================================
   الجزء الثالث
   الشراء عبر واتساب + مشاركة المنتج
========================================== */

const buyButton =
document.getElementById("buyButton");

if(buyButton){

    buyButton.onclick = function(){

        if(product.stock <= 0){

            alert("هذا المنتج غير متوفر حالياً.");

            return;

        }

        const message =
`🛍️ أرغب بشراء المنتج التالي

📦 المنتج: ${product.name}

🏷️ الماركة: ${product.brand}

💰 السعر: ${product.price} ${STORE.currency}

📦 الكمية المتوفرة: ${product.stock}`;

        const whatsapp =
        settings.social.whatsapp || "";

        if(whatsapp === ""){

            alert("لم يتم إضافة واتساب المتجر.");

            return;

        }

        window.open(
            whatsapp + "?text=" + encodeURIComponent(message),
            "_blank"
        );

    };

}

// ==========================
// مشاركة المنتج
// ==========================

const shareButton =
document.getElementById("shareButton");

if(shareButton){

    shareButton.onclick = async function(){

        if(navigator.share){

            try{

                await navigator.share({

                    title: product.name,

                    text:
                    product.name +
                    "\nالسعر: " +
                    product.price +
                    " " +
                    STORE.currency

                });

            }catch(e){}

        }else{

            alert("المشاركة غير مدعومة في هذا الجهاز.");

        }

    };

}
/* ==========================================
   الجزء الرابع
   المنتجات المشابهة + تشغيل الصفحة
========================================== */

// عرض المنتجات المشابهة
function renderRelatedProducts(){

    const relatedBox =
    document.getElementById("relatedProducts");

    if(!relatedBox) return;

    relatedBox.innerHTML = "";

    const related = products.filter(item =>

        item.category === product.category &&
        item.id !== product.id

    ).slice(0,4);

    if(related.length === 0){

        relatedBox.innerHTML =
        "<p>لا توجد منتجات مشابهة.</p>";

        return;

    }

    related.forEach(item=>{

        relatedBox.innerHTML += `

        <div class="product-card">

            <img src="${item.image}" alt="${item.name}">

            <h3>${item.name}</h3>

            <p>${item.price} ${STORE.currency}</p>

            <button onclick="goProduct(${item.id})">

                عرض المنتج

            </button>

        </div>

        `;

    });

}

// فتح منتج آخر
function goProduct(id){

    localStorage.setItem("selectedProduct", id);

    location.reload();

}

// تشغيل الصفحة
updateCartCount();
renderRelatedProducts();