/* ==========================================
   AlMajami Store V6 Professional
   login.js
   الجزء الأول
========================================== */

loadDatabase();

// عناصر الصفحة
const loginForm =
document.getElementById("loginForm");

const username =
document.getElementById("username");

const password =
document.getElementById("password");

const loginError =
document.getElementById("loginError");

const showPassword =
document.getElementById("showPassword");

// بيانات الدخول الافتراضية
const ADMIN = {

    username: "admin",

    password: "123456"

};
/* ==========================================
   الجزء الثاني
   إظهار كلمة المرور والتحقق
========================================== */

// إظهار وإخفاء كلمة المرور
showPassword.addEventListener("change", function(){

    password.type =
    this.checked ? "text" : "password";

});

// التحقق من تسجيل الدخول
function login(){

    const user =
    username.value.trim();

    const pass =
    password.value.trim();

    if(
        user === ADMIN.username &&
        pass === ADMIN.password
    ){

        sessionStorage.setItem(
            "adminLogged",
            "true"
        );

        loginError.style.display = "none";

        window.location.href =
        "admin.html";

        return;

    }

    loginError.style.display = "flex";

    password.value = "";

    password.focus();

}
/* ==========================================
   الجزء الثالث
   تنفيذ تسجيل الدخول
========================================== */

// تنفيذ عند إرسال النموذج
loginForm.addEventListener("submit", function(e){

    e.preventDefault();

    login();

});

// تنفيذ عند الضغط على Enter
username.addEventListener("keypress", function(e){

    if(e.key === "Enter"){

        e.preventDefault();

        password.focus();

    }

});

password.addEventListener("keypress", function(e){

    if(e.key === "Enter"){

        e.preventDefault();

        login();

    }

});

// إخفاء رسالة الخطأ عند الكتابة
username.addEventListener("input", function(){

    loginError.style.display = "none";

});

password.addEventListener("input", function(){

    loginError.style.display = "none";

});
/* ==========================================
   الجزء الرابع
   تذكر المستخدم والجلسة
========================================== */

// إذا كان المدير مسجل الدخول بالفعل
if(sessionStorage.getItem("adminLogged") === "true"){

    window.location.href = "admin.html";

}

// تحميل آخر اسم مستخدم
const lastUsername =
localStorage.getItem("lastUsername");

if(lastUsername){

    username.value = lastUsername;

}

// حفظ اسم المستخدم بعد تسجيل الدخول
function saveLastUsername(){

    localStorage.setItem(
        "lastUsername",
        username.value.trim()
    );

}

// تعديل دالة تسجيل الدخول
const oldLogin = login;

login = function(){

    const user =
    username.value.trim();

    const pass =
    password.value.trim();

    if(
        user === ADMIN.username &&
        pass === ADMIN.password
    ){

        saveLastUsername();

        oldLogin();

        return;

    }

    oldLogin();

};
/* ==========================================
   الجزء الخامس
   تحسينات الأمان
========================================== */

// عدد محاولات تسجيل الدخول
let loginAttempts =
Number(localStorage.getItem("loginAttempts")) || 0;

// تسجيل الدخول الآمن
const originalLogin = login;

login = function(){

    if(loginAttempts >= 5){

        alert("تم تجاوز الحد المسموح من المحاولات، أعد المحاولة بعد قليل.");

        return;

    }

    const user = username.value.trim();
    const pass = password.value.trim();

    if(
        user === ADMIN.username &&
        pass === ADMIN.password
    ){

        loginAttempts = 0;

        localStorage.setItem(
            "loginAttempts",
            "0"
        );

        loginButton.disabled = true;
        loginButton.textContent = "جاري تسجيل الدخول...";

        setTimeout(function(){

            originalLogin();

        },800);

    }else{

        loginAttempts++;

        localStorage.setItem(
            "loginAttempts",
            loginAttempts
        );

        originalLogin();

    }

};
/* ==========================================
   الجزء السادس
   التشغيل النهائي
========================================== */

// التركيز على حقل اسم المستخدم
window.addEventListener("load", function(){

    if(username.value.trim() === ""){

        username.focus();

    }else{

        password.focus();

    }

});

// منع المسافات في البداية والنهاية
username.addEventListener("blur", function(){

    username.value = username.value.trim();

});

password.addEventListener("blur", function(){

    password.value = password.value.trim();

});

// حفظ آخر وقت لفتح صفحة تسجيل الدخول
localStorage.setItem(
    "lastLoginPageOpen",
    new Date().toISOString()
);

// نهاية الملف
console.log("AlMajami Store Login V6 Loaded");