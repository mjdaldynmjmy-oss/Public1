/* ==========================================
   AlMajami Store V6 Professional
   admin.js
   الجزء الأول
========================================== */

// ==========================
// حماية لوحة الإدارة
// ==========================

if (sessionStorage.getItem("adminLogged") !== "true") {
    window.location.href = "login.html";
}

// ==========================
// تحميل قاعدة البيانات
// ==========================

loadDatabase();

// ==========================
// عناصر الصفحة
// ==========================

const pages = document.querySelectorAll(".page");

const productsTable = document.getElementById("productsTable");
const categoryList = document.getElementById("categoryList");
const ordersTable = document.getElementById("ordersTable");

let selectedImage = "";
let editIndex = -1;

// ==========================
// التنقل بين الصفحات
// ==========================

function showPage(pageId){

    pages.forEach(page=>{

        page.style.display="none";

    });

    const current=document.getElementById(pageId);

    if(current){

        current.style.display="block";

    }

    switch(pageId){

        case "products":
            refreshProducts();
        break;

        case "categories":
            refreshCategories();
        break;

        case "orders":
            loadOrders();
        break;

    }

}

// ==========================
// تسجيل الخروج
// ==========================

function logout(){

    sessionStorage.removeItem("adminLogged");

    window.location.href="login.html";

}

// ==========================
// تحديث بطاقات لوحة التحكم
// ==========================

function updateDashboard(){

    const orders =
    JSON.parse(localStorage.getItem("orders")) || [];

    document.getElementById("productsCount").textContent =
    products.length;

    document.getElementById("categoriesCount").textContent =
    Math.max(categories.length-1,0);

    document.getElementById("featuredCount").textContent =
    products.filter(p=>p.featured).length;

    document.getElementById("newCount").textContent =
    products.filter(p=>p.newProduct).length;

    document.getElementById("ordersCount").textContent =
    orders.length;

}
/* ==========================================
   الجزء الثاني
   إدارة المنتجات
========================================== */

// معاينة الصورة
document.getElementById("productImage").addEventListener("change",function(e){

    const file=e.target.files[0];

    if(!file) return;

    const reader=new FileReader();

    reader.onload=function(){

        selectedImage=reader.result;

        document.getElementById("previewImage").src=selectedImage;
        document.getElementById("previewImage").style.display="block";

    };

    reader.readAsDataURL(file);

});

// حفظ أو تعديل منتج
document.getElementById("saveProduct").onclick=function(){

    const product={

        id:editIndex>=0?products[editIndex].id:Date.now(),

        name:document.getElementById("productName").value.trim(),

        brand:document.getElementById("productBrand").value.trim(),

        category:document.getElementById("productCategory").value,

        price:Number(document.getElementById("productPrice").value),

        oldPrice:Number(document.getElementById("productOldPrice").value),

        stock:Number(document.getElementById("productStock").value),

        description:document.getElementById("productDescription").value.trim(),

        image:selectedImage||"images/no-image.png",

        featured:document.getElementById("featured").checked,

        newProduct:document.getElementById("newProduct").checked

    };

    if(product.name===""){

        alert("يرجى إدخال اسم المنتج");

        return;

    }

    if(editIndex>=0){

        products[editIndex]=product;

    }else{

        products.push(product);

    }

    saveDatabase();

    refreshProducts();

    updateDashboard();

    clearForm();

    alert("✅ تم حفظ المنتج");

};

// عرض المنتجات
function refreshProducts(){ 
  
    if(!productsTable) return;

    productsTable.innerHTML="";

    products.forEach((product,index)=>{

        productsTable.innerHTML+=`

<div class="product-card-admin">

<img src="${product.image}" alt="${product.name}">

<h3>${product.name}</h3>

<p>${product.price} ${STORE.currency}</p>

<p>${product.category}</p>

<p>📦 الكمية: <b>${product.stock}</b></p>

<p>

${
product.stock===0
?"<span style='color:red;font-weight:bold;'>🔴 نفد المخزون</span>"
:product.stock<=5
?"<span style='color:orange;font-weight:bold;'>🟡 كمية قليلة</span>"
:"<span style='color:green;font-weight:bold;'>🟢 متوفر</span>"
}

</p>

<div style="display:flex;gap:10px;margin-top:10px;">

<button onclick="editProduct(${index})">
✏️ تعديل
</button>

<button onclick="deleteProduct(${index})">
🗑 حذف
</button>

</div>

</div>

`;

    });

}
/* ==========================================
   الجزء الثالث
   تعديل - حذف - تنظيف النموذج
========================================== */

// تعديل منتج
function editProduct(index){

    editIndex = index;

    const product = products[index];

    document.getElementById("productName").value = product.name;
    document.getElementById("productBrand").value = product.brand;
    document.getElementById("productCategory").value = product.category;
    document.getElementById("productPrice").value = product.price;
    document.getElementById("productOldPrice").value = product.oldPrice;
    document.getElementById("productStock").value = product.stock;
    document.getElementById("productDescription").value = product.description;

    document.getElementById("featured").checked = product.featured;
    document.getElementById("newProduct").checked = product.newProduct;

    selectedImage = product.image;

    document.getElementById("previewImage").src = product.image;
    document.getElementById("previewImage").style.display = "block";

    window.scrollTo({
        top:0,
        behavior:"smooth"
    });

    showPage("products");

}

// حذف منتج
function deleteProduct(index){

    if(!confirm("هل تريد حذف المنتج؟")) return;

    products.splice(index,1);

  
  saveDatabase();
  
console.log("Products after save:", localStorage.getItem("products"));
    refreshProducts();

    updateDashboard();

}

// تنظيف النموذج
function clearForm(){

    editIndex = -1;

    selectedImage = "";

    document.getElementById("productName").value = "";
    document.getElementById("productBrand").value = "";
    document.getElementById("productCategory").selectedIndex = 0;
    document.getElementById("productPrice").value = "";
    document.getElementById("productOldPrice").value = "";
    document.getElementById("productStock").value = "";
    document.getElementById("productDescription").value = "";

    document.getElementById("featured").checked = false;
    document.getElementById("newProduct").checked = false;

    document.getElementById("previewImage").src = "";
    document.getElementById("previewImage").style.display = "none";

    document.getElementById("productImage").value = "";

}
/* ==========================================
   الجزء الرابع
   إدارة التصنيفات والطلبات
========================================== */

// ======================
// عرض التصنيفات
// ======================

function refreshCategories(){

    if(!categoryList) return;

    categoryList.innerHTML="";

    categories.forEach((category,index)=>{

        if(category==="الكل") return;

        categoryList.innerHTML+=`

<div class="product-card-admin">

<h3>${category}</h3>

<button onclick="deleteCategory(${index})">

🗑 حذف

</button>

</div>

`;

    });

}

// إضافة تصنيف
document.getElementById("addCategory").onclick=function(){

    const value=document.getElementById("newCategory").value.trim();

    if(value===""){

        alert("يرجى إدخال اسم التصنيف");

        return;

    }

    if(categories.includes(value)){

        alert("التصنيف موجود مسبقاً");

        return;

    }

    categories.push(value);

    saveDatabase();
alert(localStorage.getItem("products"));
    refreshCategories();

    updateDashboard();

    document.getElementById("newCategory").value="";

};

// حذف تصنيف
function deleteCategory(index){

    if(!confirm("هل تريد حذف التصنيف؟")) return;

    categories.splice(index,1);

    saveDatabase();

    refreshCategories();

    updateDashboard();

}

// ======================
// عرض الطلبات
// ======================

function loadOrders(){

    if(!ordersTable) return;

    const orders=
    JSON.parse(localStorage.getItem("orders")) || [];

    const keyword=(
        document.getElementById("searchOrder")?.value || ""
    ).toLowerCase();

    ordersTable.innerHTML="";

    if(orders.length===0){

        ordersTable.innerHTML=
        "<p style='text-align:center;padding:30px;'>لا توجد طلبات</p>";

        return;

    }

    orders.forEach((order,index)=>{

        if(
            keyword &&
            !order.customerName.toLowerCase().includes(keyword) &&
            !order.customerPhone.includes(keyword)
        ){
            return;
        }

        ordersTable.innerHTML+=`

<div class="product-card-admin">

<h3>📦 طلب رقم ${index+1}</h3>

<p><b>العميل:</b> ${order.customerName}</p>

<p><b>الهاتف:</b> ${order.customerPhone}</p>

<p><b>الإجمالي:</b> ${order.total} ${STORE.currency}</p>

<p><b>الحالة:</b> ${order.status || "جديد"}</p>

<button onclick="deleteOrder(${index})">

🗑 حذف الطلب

</button>

</div>

`;

    });

}

// حذف طلب
function deleteOrder(index){

    if(!confirm("هل تريد حذف الطلب؟")) return;

    const orders=
    JSON.parse(localStorage.getItem("orders")) || [];

    orders.splice(index,1);

    localStorage.setItem(
        "orders",
        JSON.stringify(orders)
    );

    loadOrders();

    updateDashboard();

}

// البحث
const searchOrder=document.getElementById("searchOrder");

if(searchOrder){

    searchOrder.addEventListener("keyup",loadOrders);

}
/* ==========================================
   الجزء الخامس
   Dashboard Analytics
========================================== */

function updateStatistics(){

    const orders =
    JSON.parse(localStorage.getItem("orders")) || [];

    let totalSales = 0;
    let totalItems = 0;

    const sold = {};

    orders.forEach(order=>{

        totalSales += Number(order.total || 0);

        (order.items || []).forEach(item=>{

            totalItems += Number(item.qty || 0);

            if(!sold[item.id]){
                sold[item.id] = 0;
            }

            sold[item.id] += Number(item.qty || 0);

        });

    });

    let stockValue = 0;
    let lowStock = 0;

    let topProduct = "لا يوجد";
    let topQty = 0;

    products.forEach(product=>{

        stockValue +=
        Number(product.price) *
        Number(product.stock);

        if(product.stock <= 5){

            lowStock++;

        }

        const qty = sold[product.id] || 0;

        if(qty > topQty){

            topQty = qty;

            topProduct = product.name;

        }

    });

    if(document.getElementById("totalSales"))
        document.getElementById("totalSales").textContent =
        totalSales + " " + STORE.currency;

    if(document.getElementById("totalItems"))
        document.getElementById("totalItems").textContent =
        totalItems;

    if(document.getElementById("stockValue"))
        document.getElementById("stockValue").textContent =
        stockValue + " " + STORE.currency;

    if(document.getElementById("topProduct"))
        document.getElementById("topProduct").textContent =
        topProduct;

    if(document.getElementById("lowStock"))
        document.getElementById("lowStock").textContent =
        lowStock;

    const warning =
    document.getElementById("stockWarning");

    if(warning){

        if(lowStock > 0){

            warning.style.display = "block";

            warning.innerHTML =
            `⚠️ يوجد ${lowStock} منتج كمية مخزونه قليلة`;

        }else{

            warning.style.display = "none";

        }

    }

}
 /* ==========================================
   الجزء السادس
   التشغيل النهائي
========================================== */

// تحديث كل البيانات
function refreshAll(){

    refreshProducts();

    refreshCategories();

    loadOrders();

    updateDashboard();

    updateStatistics();

}

// زر الإعدادات
const openSettings =
document.getElementById("openSettings");

if(openSettings){

    openSettings.onclick=function(){

        window.location.href="settings.html";

    };

}

// زر التواصل
const openSocial =
document.getElementById("openSocial");

if(openSocial){

    openSocial.onclick=function(){

        window.location.href="settings.html#social";

    };

}

// تشغيل الصفحة
window.addEventListener("load",function(){

    refreshAll();

    showPage("dashboard");

});

// تحديث تلقائي بعد حفظ منتج
const saveButton =
document.getElementById("saveProduct");

if(saveButton){

    const oldSave = saveButton.onclick;

    saveButton.onclick=function(){

        oldSave();

        refreshAll();

    };

} 