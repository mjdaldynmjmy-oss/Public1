/* ==========================================
   AlMajami Store V6 Professional
   cart.js
   الجزء الأول
========================================== */

loadDatabase();

// تحميل السلة
let cart =
JSON.parse(localStorage.getItem("cart")) || [];

// عناصر الصفحة
const cartItems =
document.getElementById("cartItems");

const cartTotal =
document.getElementById("cartTotal");

const customerName =
document.getElementById("customerName");

const customerPhone =
document.getElementById("customerPhone");

const customerAddress =
document.getElementById("customerAddress");

// عرض السلة
function renderCart(){

    if(!cartItems) return;

    cartItems.innerHTML="";

    let total=0;

    if(cart.length===0){

        cartItems.innerHTML=`

<div class="empty-box">

<h2>🛒 السلة فارغة</h2>

<p>

لم تقم بإضافة أي منتج بعد.

</p>

</div>

`;

        if(cartTotal){

            cartTotal.textContent="0";

        }

        return;

    }

    cart.forEach((product,index)=>{

        const qty=
        Number(product.qty||1);

        const price=
        Number(product.price);

        total += qty * price;
              cartItems.innerHTML += `

<div class="cart-item">

    <img
    src="${product.image}"
    alt="${product.name}">

    <div class="cart-info">

        <h3>${product.name}</h3>

        <p>

        ${price} ${STORE.currency}

        </p>

        <div class="cart-qty">

            <button
            onclick="changeQty(${index},-1)">
            ➖
            </button>

            <span>

            ${qty}

            </span>

            <button
            onclick="changeQty(${index},1)">
            ➕

            </button>

        </div>

        <p>

        الإجمالي:
        <b>

        ${qty * price}
        ${STORE.currency}

        </b>

        </p>

        <button
        class="delete-btn"
        onclick="removeCart(${index})">

        🗑 حذف

        </button>

    </div>

</div>

`;

    });

    if(cartTotal){

        cartTotal.textContent = total;

    }

}

// حذف منتج
function removeCart(index){

    cart.splice(index,1);

    localStorage.setItem(
        "cart",
        JSON.stringify(cart)
    );

    renderCart();

}
/* ==========================================
   الجزء الثالث
   إدارة الكمية والتحقق من المخزون
========================================== */

// تغيير الكمية
function changeQty(index, value){

    const product =
    products.find(p => p.id === cart[index].id);

    if(!product){

        alert("المنتج غير موجود.");

        return;

    }

    let newQty =
    Number(cart[index].qty || 1) + value;

    if(newQty <= 0){

        removeCart(index);

        return;

    }

    if(newQty > product.stock){

        alert(
            "الكمية المطلوبة أكبر من المخزون المتوفر.\nالمتبقي: " +
            product.stock
        );

        return;

    }

    cart[index].qty = newQty;

    localStorage.setItem(
        "cart",
        JSON.stringify(cart)
    );

    renderCart();

}

// التحقق من المخزون قبل إرسال الطلب
function checkStock(){

    for(const cartItem of cart){

        const product =
        products.find(p => p.id === cartItem.id);

        if(!product){

            alert("أحد المنتجات غير موجود.");

            return false;

        }

        if(product.stock < cartItem.qty){

            alert(
                `المنتج "${product.name}" لا تتوفر منه الكمية المطلوبة.\nالمتبقي: ${product.stock}`
            );

            return false;

        }

    }

    return true;

}
/* ==========================================
   الجزء الرابع
   إرسال الطلب
========================================== */

document.getElementById("sendOrder").onclick = function(){

    if(cart.length === 0){

        alert("السلة فارغة");

        return;

    }

    if(!checkStock()){

        return;

    }

    const name =
    customerName.value.trim();

    const phone =
    customerPhone.value.trim();

    const address =
    customerAddress.value.trim();

    if(name === "" || phone === ""){

        alert("يرجى إدخال الاسم ورقم الهاتف");

        return;

    }

    let total = 0;

    let message =
`🛍️ طلب جديد - ${settings.storeName}

━━━━━━━━━━━━━━━━━━

👤 الاسم: ${name}
📞 الهاتف: ${phone}
📍 العنوان: ${address}

📅 التاريخ: ${new Date().toLocaleDateString("ar")}
🕒 الوقت: ${new Date().toLocaleTimeString("ar")}

━━━━━━━━━━━━━━━━━━
📦 المنتجات المطلوبة:

`;

    cart.forEach(item=>{

        const qty =
        Number(item.qty || 1);

        const subtotal =
        qty * Number(item.price);

        total += subtotal;

        message +=
`🔹 ${item.name}

• الكمية: ${qty}
• السعر: ${item.price} ${STORE.currency}
• الإجمالي: ${subtotal} ${STORE.currency}

`;

    });

    message +=
`━━━━━━━━━━━━━━━━━━

💰 الإجمالي:
${total} ${STORE.currency}`;

    // حفظ الطلب
    const orders =
    JSON.parse(localStorage.getItem("orders")) || [];

    orders.push({

        customerName: name,

        customerPhone: phone,

        customerAddress: address,

        total,

        items: [...cart],

        status: "جديد",

        date: new Date().toLocaleString("ar")

    });

    localStorage.setItem(
        "orders",
        JSON.stringify(orders)
    );
  /* ==========================================
   الجزء الخامس
   خصم المخزون وإرسال الطلب
========================================== */

    // خصم الكمية من المخزون
    cart.forEach(cartItem => {

        const product = products.find(
            p => p.id === cartItem.id
        );

        if(product){

            product.stock -= Number(cartItem.qty);

            if(product.stock < 0){

                product.stock = 0;

            }

        }

    });

    // حفظ قاعدة البيانات
    saveDatabase();

    // رابط واتساب
    const whatsapp =
    settings.social.whatsapp || "";

    if(whatsapp === ""){

        alert("يرجى إضافة رابط واتساب في الإعدادات.");

        return;

    }

    window.open(

        whatsapp +
        "?text=" +
        encodeURIComponent(message),

        "_blank"

    );

    // تفريغ السلة
    localStorage.removeItem("cart");

    cart = [];

    alert("✅ تم إرسال الطلب بنجاح.");

    window.location.href = "index.html";

};
/* ==========================================
   الجزء السادس
   تحديث السلة وتشغيل الصفحة
========================================== */

// تحديث السلة
function refreshCart(){

    loadDatabase();

    cart = JSON.parse(localStorage.getItem("cart")) || [];

    renderCart();

}

// حفظ السلة
function saveCart(){

    localStorage.setItem(
        "cart",
        JSON.stringify(cart)
    );

}

// تحديث عند الرجوع للصفحة
window.addEventListener("pageshow", function(){

    refreshCart();

});

// تحديث عند تغيير localStorage
window.addEventListener("storage", function(e){

    if(e.key === "cart"){

        refreshCart();

    }

});

// تشغيل أول مرة
renderCart();
/* ==========================================
   الجزء السابع
   تحسينات السلة
========================================== */

// تحديث عداد السلة
function updateCartCounter(){

    let totalItems = 0;

    cart.forEach(item=>{

        totalItems += Number(item.qty || 1);

    });

    const counter =
    document.getElementById("cartCount");

    if(counter){

        counter.textContent = totalItems;

    }

}

// تنظيف السلة بالكامل
function clearCart(){

    if(!confirm("هل تريد إفراغ السلة بالكامل؟")){

        return;

    }

    cart = [];

    saveCart();

    renderCart();

    updateCartCounter();

}

// إزالة المنتجات غير الموجودة
function removeInvalidProducts(){

    cart = cart.filter(item =>

        products.some(product =>
            product.id === item.id
        )

    );

    saveCart();

}

// تحديث كامل للسلة
function refreshCartData(){

    removeInvalidProducts();

    renderCart();

    updateCartCounter();

}
/* ==========================================
   الجزء الثامن
   التشغيل النهائي
========================================== */

// تهيئة صفحة السلة
function initializeCart(){

    loadDatabase();

    cart = JSON.parse(localStorage.getItem("cart")) || [];

    removeInvalidProducts();

    renderCart();

    updateCartCounter();

}

// تحديث عند استعادة التركيز للتطبيق
window.addEventListener("focus", function(){

    initializeCart();

});

// حفظ السلة تلقائياً
window.addEventListener("beforeunload", function(){

    saveCart();

});

// تشغيل الصفحة
document.addEventListener("DOMContentLoaded", function(){

    initializeCart();

});

// آخر تحديث
localStorage.setItem(
    "lastCartUpdate",
    new Date().toISOString()
);

// نهاية الملف