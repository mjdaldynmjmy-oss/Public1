/* ==========================================
   AlMajami Store V6 Professional
   settings.js
   الجزء الأول
========================================== */

loadDatabase();

// ==========================
// عناصر الصفحة
// ==========================

const storeName =
document.getElementById("storeName");

const storeDescription =
document.getElementById("storeDescription");

const storeLogo =
document.getElementById("storeLogo");

const storeBanner =
document.getElementById("storeBanner");

const primaryColor =
document.getElementById("primaryColor");

const secondaryColor =
document.getElementById("secondaryColor");

const backgroundColor =
document.getElementById("backgroundColor");

const textColor =
document.getElementById("textColor");

// روابط التواصل
const whatsapp =
document.getElementById("whatsapp");

const facebook =
document.getElementById("facebook");

const instagram =
document.getElementById("instagram");

const telegram =
document.getElementById("telegram");

const youtube =
document.getElementById("youtube");
/* ==========================================
   الجزء الثاني
   تحميل الإعدادات
========================================== */

function loadSettings(){

    // بيانات المتجر
    storeName.value =
    settings.storeName || "";

    storeDescription.value =
    settings.description || "";

    primaryColor.value =
    settings.theme.primary || "#0d6efd";

    secondaryColor.value =
    settings.theme.secondary || "#198754";

    backgroundColor.value =
    settings.theme.background || "#f5f7fb";

    textColor.value =
    settings.theme.text || "#222222";

    // روابط التواصل
    whatsapp.value =
    settings.social.whatsapp || "";

    facebook.value =
    settings.social.facebook || "";

    instagram.value =
    settings.social.instagram || "";

    telegram.value =
    settings.social.telegram || "";

    youtube.value =
    settings.social.youtube || "";

    // معاينة الصور
    if(settings.logo){

        document.getElementById("logoPreview").src =
        settings.logo;

    }

    if(settings.banner){

        document.getElementById("bannerPreview").src =
        settings.banner;

    }

}

// تشغيل تحميل الإعدادات
loadSettings();
/* ==========================================
   الجزء الثالث
   رفع الشعار والبنر
========================================== */

// رفع الشعار
storeLogo.addEventListener("change", function(e){

    const file = e.target.files[0];

    if(!file) return;

    const reader = new FileReader();

    reader.onload = function(){

        settings.logo = reader.result;

        document.getElementById("logoPreview").src =
        reader.result;

    };

    reader.readAsDataURL(file);

});

// رفع البنر
storeBanner.addEventListener("change", function(e){

    const file = e.target.files[0];

    if(!file) return;

    const reader = new FileReader();

    reader.onload = function(){

        settings.banner = reader.result;

        document.getElementById("bannerPreview").src =
        reader.result;

    };

    reader.readAsDataURL(file);

});
/* ==========================================
   الجزء الرابع
   حفظ الإعدادات
========================================== */

document.getElementById("saveSettings").onclick = function(){

    // بيانات المتجر
    settings.storeName =
    storeName.value.trim();

    settings.description =
    storeDescription.value.trim();

    // الألوان
    settings.theme.primary =
    primaryColor.value;

    settings.theme.secondary =
    secondaryColor.value;

    settings.theme.background =
    backgroundColor.value;

    settings.theme.text =
    textColor.value;

    // روابط التواصل
    settings.social.whatsapp =
    whatsapp.value.trim();

    settings.social.facebook =
    facebook.value.trim();

    settings.social.instagram =
    instagram.value.trim();

    settings.social.telegram =
    telegram.value.trim();

    settings.social.youtube =
    youtube.value.trim();

    // حفظ قاعدة البيانات
    saveDatabase();

    alert("✅ تم حفظ إعدادات المتجر بنجاح");

};
/* ==========================================
   الجزء الخامس
   إعادة التعيين والمعاينة المباشرة
========================================== */

// معاينة الألوان مباشرة
function previewTheme(){

    document.documentElement.style.setProperty(
        "--primary",
        primaryColor.value
    );

    document.documentElement.style.setProperty(
        "--secondary",
        secondaryColor.value
    );

    document.documentElement.style.setProperty(
        "--background",
        backgroundColor.value
    );

    document.documentElement.style.setProperty(
        "--text",
        textColor.value
    );

}

primaryColor.addEventListener("input", previewTheme);
secondaryColor.addEventListener("input", previewTheme);
backgroundColor.addEventListener("input", previewTheme);
textColor.addEventListener("input", previewTheme);

// إعادة الإعدادات الافتراضية
const resetButton =
document.getElementById("resetSettings");

if(resetButton){

    resetButton.onclick = function(){

        if(!confirm("هل تريد استعادة الإعدادات الافتراضية؟")){
            return;
        }

        createDatabase();

        saveDatabase();

        loadSettings();

        previewTheme();

        alert("✅ تم استعادة الإعدادات الافتراضية.");

    };

}
/* ==========================================
   الجزء السادس
   التشغيل النهائي
========================================== */

// التحقق من وجود العناصر الأساسية
function initializeSettings(){

    if(!settings.theme){

        settings.theme = {
            primary:"#0d6efd",
            secondary:"#198754",
            background:"#f5f7fb",
            text:"#222222"
        };

    }

    if(!settings.social){

        settings.social = {
            whatsapp:"",
            facebook:"",
            instagram:"",
            telegram:"",
            youtube:""
        };

    }

    loadSettings();

    previewTheme();

}

// حفظ تلقائي عند مغادرة الصفحة
window.addEventListener("beforeunload",function(){

    saveDatabase();

});

// تشغيل الصفحة
initializeSettings();