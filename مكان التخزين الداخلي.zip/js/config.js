/* ==========================================
   AlMajami Store V6 Professional
   config.js
   الجزء الأول
========================================== */

// معلومات التطبيق
const APP = {

    name: "AlMajami Store",

    version: "6.0.0",

    author: "AlMajami",

    language: "ar",

    direction: "rtl"

};

// إعدادات المتجر
const STORE = {

    currency: "ريال",

    tax: 0,

    shipping: 0,

    allowOrders: true,

    allowCart: true,

    allowWhatsApp: true

};

// مفاتيح التخزين
const STORAGE = {

    products: "products",

    categories: "categories",

    settings: "settings",

    cart: "cart",

    orders: "orders"

};
/* ==========================================
   الجزء الثاني
   إعدادات الواجهة والرسائل
========================================== */

// إعدادات الواجهة
const UI = {

    animation: true,

    lazyLoading: true,

    darkMode: false,

    showLoader: true,

    showWhatsAppButton: true,

    showBackToTop: true,

    itemsPerPage: 20

};

// رسائل النظام
const MESSAGES = {

    loading: "جاري التحميل...",

    noProducts: "لا توجد منتجات حالياً.",

    emptyCart: "السلة فارغة.",

    addedToCart: "✅ تمت إضافة المنتج إلى السلة.",

    orderSent: "✅ تم إرسال الطلب بنجاح.",

    saved: "✅ تم حفظ البيانات بنجاح.",

    deleted: "🗑️ تم الحذف بنجاح.",

    confirmDelete: "هل تريد الحذف؟",

    networkError: "حدث خطأ، حاول مرة أخرى."

};
/* ==========================================
   الجزء الثالث
   دوال مساعدة والتشغيل
========================================== */

// تنسيق الأسعار
function formatPrice(price){

    return Number(price).toLocaleString("ar") +
    " " + STORE.currency;

}

// تنسيق التاريخ
function formatDate(date){

    return new Date(date).toLocaleString("ar");

}

// التحقق من تشغيل الطلبات
function canOrder(){

    return STORE.allowOrders === true;

}

// التحقق من تشغيل السلة
function canUseCart(){

    return STORE.allowCart === true;

}

// التحقق من تشغيل واتساب
function canUseWhatsApp(){

    return STORE.allowWhatsApp === true;

}

// معلومات الإصدار
console.log(
    `${APP.name} v${APP.version} تم التشغيل بنجاح`
);

// منع تعديل الكائنات العامة
Object.freeze(APP);
Object.freeze(STORE);
Object.freeze(STORAGE);
Object.freeze(UI);
Object.freeze(MESSAGES);

/* ==========================================
   نهاية الملف
========================================== */